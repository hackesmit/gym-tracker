LOTR-inspired SVG icon set for gym tracker dashboard.
Files are 128x128 SVG.
